package com.beeper.app

import android.bluetooth.*
import android.content.*
import android.os.Build
import android.os.ParcelUuid
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.*
import java.util.*

class BluetoothManager(
    private val context: Context,
    private val onMessageReceived: (String, String) -> Unit // (отправитель, сообщение)
) {
    
    companion object {
        private const val TAG = "Beeper-BT"
        private val APP_UUID = ParcelUuid.fromString("a1b2c3d4-e5f6-7890-1234-567890abcdef")
        private const val SERVICE_NAME = "BeeperChat"
        private const val CHANNEL_ID = "beeper_bt_channel"
    }
    
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var clientSocket: BluetoothSocket? = null
    private var isServerRunning = false
    private var connectedThread: ConnectedThread? = null
    
    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    if (device != null && device.name != null) {
                        Log.d(TAG, "Найдено устройство: ${device.name} - ${device.address}")
                        // Можно добавить в список для отображения пользователю
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    Log.d(TAG, "Поиск устройств завершён")
                }
            }
        }
    }
    
    init {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
    }
    
    /**
     * Проверка поддержки Bluetooth
     */
    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null
    
    /**
     * Включён ли Bluetooth
     */
    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true
    
    /**
     * Запуск сервера (ожидание подключений)
     */
    fun startServer(): Boolean {
        if (!isBluetoothEnabled()) {
            Log.e(TAG, "Bluetooth выключен")
            return false
        }
        
        try {
            // Используем RFCOMM (SPP профиль)
            serverSocket = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                bluetoothAdapter?.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, APP_UUID.uuid)
            } else {
                bluetoothAdapter?.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, APP_UUID.uuid)
            }
            
            isServerRunning = true
            Thread {
                while (isServerRunning) {
                    try {
                        val socket = serverSocket?.accept()
                        socket?.let {
                            Log.d(TAG, "Клиент подключился: ${it.remoteDevice.name}")
                            connectedThread = ConnectedThread(it, true)
                            connectedThread?.start()
                        }
                    } catch (e: IOException) {
                        Log.e(TAG, "Ошибка приёма подключения: ${e.message}")
                        break
                    }
                }
            }.start()
            
            Log.d(TAG, "Сервер запущен")
            return true
        } catch (e: IOException) {
            Log.e(TAG, "Ошибка запуска сервера: ${e.message}")
            return false
        }
    }
    
    /**
     * Поиск и подключение к устройству
     */
    fun connectToDevice(deviceAddress: String, callback: (Boolean) -> Unit) {
        if (!isBluetoothEnabled()) {
            callback(false)
            return
        }
        
        val device = bluetoothAdapter?.getRemoteDevice(deviceAddress)
        if (device == null) {
            Log.e(TAG, "Устройство не найдено")
            callback(false)
            return
        }
        
        Thread {
            try {
                val socket = device.createInsecureRfcommSocketToServiceRecord(APP_UUID.uuid)
                socket.connect()
                clientSocket = socket
                connectedThread = ConnectedThread(socket, false)
                connectedThread?.start()
                Log.d(TAG, "Подключено к ${device.name}")
                callback(true)
            } catch (e: IOException) {
                Log.e(TAG, "Ошибка подключения: ${e.message}")
                callback(false)
            }
        }.start()
    }
    
    /**
     * Поиск устройств в радиусе
     */
    fun discoverDevices(deviceFoundCallback: (BluetoothDevice) -> Unit) {
        if (!isBluetoothEnabled()) return
        
        // Регистрируем ресивер
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        context.registerReceiver(broadcastReceiver, filter)
        
        // Начинаем поиск
        bluetoothAdapter?.startDiscovery()
        
        // Временно подписываемся на события
        val tempReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                        device?.let { deviceFoundCallback(it) }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        context?.unregisterReceiver(this)
                    }
                }
            }
        }
        context.registerReceiver(tempReceiver, filter)
    }
    
    /**
     * Отправка сообщения
     */
    fun sendMessage(message: String): Boolean {
        connectedThread?.let {
            it.write(message)
            return true
        }
        Log.e(TAG, "Нет активного подключения")
        return false
    }
    
    /**
     * Остановка сервера и закрытие соединений
     */
    fun stop() {
        isServerRunning = false
        try {
            serverSocket?.close()
            clientSocket?.close()
            connectedThread?.cancel()
        } catch (e: IOException) {
            Log.e(TAG, "Ошибка закрытия соединений: ${e.message}")
        }
        
        try {
            context.unregisterReceiver(broadcastReceiver)
        } catch (e: IllegalArgumentException) {
            // Ресивер не был зарегистрирован
        }
    }
    
    /**
     * Поток для приёма/передачи данных
     */
    inner class ConnectedThread(private val socket: BluetoothSocket, private val isServerMode: Boolean) : Thread() {
        
        private val inputStream: InputStream? = socket.inputStream
        private val outputStream: OutputStream? = socket.outputStream
        private var isRunning = true
        
        override fun run() {
            val buffer = ByteArray(1024)
            
            while (isRunning) {
                try {
                    val bytes = inputStream?.read(buffer) ?: -1
                    if (bytes > 0) {
                        val received = String(buffer, 0, bytes)
                        val senderName = if (isServerMode) socket.remoteDevice.name ?: "BT Client" else "BT Peer"
                        Log.d(TAG, "Получено: $received от $senderName")
                        
                        // Вызываем колбэк в UI потоке
                        android.os.Handler(context.mainLooper).post {
                            onMessageReceived(senderName, received)
                        }
                    }
                } catch (e: IOException) {
                    Log.e(TAG, "Ошибка чтения: ${e.message}")
                    isRunning = false
                }
            }
        }
        
        fun write(message: String) {
            try {
                outputStream?.write(message.toByteArray())
                outputStream?.flush()
                Log.d(TAG, "Отправлено: $message")
            } catch (e: IOException) {
                Log.e(TAG, "Ошибка отправки: ${e.message}")
            }
        }
        
        fun cancel() {
            isRunning = false
            try {
                socket.close()
            } catch (e: IOException) {
                Log.e(TAG, "Ошибка закрытия сокета: ${e.message}")
            }
        }
    }
}