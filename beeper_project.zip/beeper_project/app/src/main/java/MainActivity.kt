package com.beeper.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {
    
    private lateinit var tvOutput: TextView
    private lateinit var btnKey: Button
    private lateinit var switchMode: SwitchMaterial
    
    private var currentMode = "SERVER" // SERVER или BLUETOOTH
    private var bluetoothManager: BluetoothManager? = null
    
    companion object {
        private const val REQUEST_BLUETOOTH_PERMISSIONS = 1001
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        tvOutput = findViewById(R.id.tvOutput)
        btnKey = findViewById(R.id.btnKey)
        switchMode = findViewById(R.id.switchMode)
        
        setupModeSwitch()
        setupKeyButton()
        
        // Инициализация Bluetooth менеджера
        bluetoothManager = BluetoothManager(this) { sender, message ->
            runOnUiThread {
                showMessage("[$sender]: $message")
                saveToLocalLog("$sender: $message", false)
            }
        }
    }
    
    private fun setupModeSwitch() {
        switchMode.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                currentMode = "BLUETOOTH"
                Toast.makeText(this, "Режим Bluetooth (Прямой канал)", Toast.LENGTH_SHORT).show()
                checkBluetoothPermissionsAndStart()
            } else {
                currentMode = "SERVER"
                bluetoothManager?.stop()
                Toast.makeText(this, "Режим Эфир (Сервер)", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun checkBluetoothPermissionsAndStart() {
        val permissions = mutableListOf<String>()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_ADMIN)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
        
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_BLUETOOTH_PERMISSIONS)
        } else {
            startBluetoothMode()
        }
    }
    
    private fun startBluetoothMode() {
        if (bluetoothManager?.isBluetoothEnabled() != true) {
            Toast.makeText(this, "Пожалуйста, включите Bluetooth", Toast.LENGTH_LONG).show()
            val intent = android.content.Intent(android.bluetooth.BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(intent)
            return
        }
        
        // Показываем диалог выбора: Сервер или Клиент
        val options = arrayOf("Создать чат (Сервер)", "Подключиться к чату (Клиент)")
        AlertDialog.Builder(this)
            .setTitle("Режим Bluetooth")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startBluetoothServer()
                    1 -> discoverAndConnect()
                }
            }
            .show()
    }
    
    private fun startBluetoothServer() {
        val success = bluetoothManager?.startServer() == true
        if (success) {
            Toast.makeText(this, "Чат создан. Ожидание подключения...", Toast.LENGTH_LONG).show()
            tvOutput.text = "Режим сервера\nОжидание подключения..."
        } else {
            Toast.makeText(this, "Не удалось запустить сервер", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun discoverAndConnect() {
        Toast.makeText(this, "Поиск устройств...", Toast.LENGTH_SHORT).show()
        
        val devices = mutableListOf<android.bluetooth.BluetoothDevice>()
        
        bluetoothManager?.discoverDevices { device ->
            if (!devices.contains(device)) {
                devices.add(device)
                // Показываем список найденных устройств
                runOnUiThread {
                    val deviceNames = devices.map { "${it.name} (${it.address})" }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("Выберите устройство")
                        .setItems(deviceNames) { _, index ->
                            val selectedDevice = devices[index]
                            bluetoothManager?.connectToDevice(selectedDevice.address) { success ->
                                runOnUiThread {
                                    if (success) {
                                        Toast.makeText(this, "Подключено к ${selectedDevice.name}", Toast.LENGTH_SHORT).show()
                                        tvOutput.text = "Подключено: ${selectedDevice.name}\nГотов к отправке"
                                    } else {
                                        Toast.makeText(this, "Ошибка подключения", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                        .show()
                }
            }
        }
    }
    
    private fun setupKeyButton() {
        btnKey.setOnClickListener {
            // Здесь логика набора и отправки сообщения (как в предыдущей версии)
            // При отправке проверяем currentMode
            when (currentMode) {
                "SERVER" -> {
                    // Отправка через HTTP сервер
                    sendViaServer(currentText)
                }
                "BLUETOOTH" -> {
                    if (bluetoothManager?.sendMessage(currentText) == true) {
                        Toast.makeText(this, "Отправлено по Bluetooth", Toast.LENGTH_SHORT).show()
                        saveToLocalLog(currentText, true)
                        currentText = ""
                    } else {
                        Toast.makeText(this, "Нет Bluetooth подключения", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    
    private fun sendViaServer(message: String) {
        // Здесь код отправки на HTTP сервер (как в предыдущей версии)
    }
    
    private fun showMessage(msg: String) {
        tvOutput.text = "$msg\n${tvOutput.text}"
        // Воспроизводим звук/вибрацию
    }
    
    private fun saveToLocalLog(message: String, isOutgoing: Boolean) {
        // Код сохранения лога (как в предыдущей версии)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        bluetoothManager?.stop()
    }
}